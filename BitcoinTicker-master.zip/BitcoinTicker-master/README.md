# BitcoinTicker
Learn to make iOS Apps 📱 | Project Stub | (Swift 3.0/Xcode 8) - Bitcoin Ticker App

Download the starter project files as .zip and extract to your desktop. ^^

## Finished App
![Finished App](http://i.giphy.com/l0HlQGzz2MQCKIBI4.gif)

Copyright 2016 London App Brewery
